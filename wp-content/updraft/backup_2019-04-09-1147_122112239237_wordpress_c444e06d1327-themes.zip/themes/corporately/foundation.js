/*jslint browser: true*/
/*global $, jQuery*/
(function($) {
    $(document).ready(function() {
	$(document).foundation();
    })
}(jQuery));
