=== Content ===

Contributors: spicethemes
Requires at least: 4.7
Tested up to: 4.9.5
Stable tag: 1.3

Multi-purpose WordPress theme

== Description ==

Content is a responsive, multi-purpose WordPress theme. It’s flexible and suitable for agencies, blogs, business, corporate or portfolios. Customization is easy and straight-forward, with options provided that allow you to setup your site to perfectly fit your desired online presence. Content offers a beautifully designed masonry blog layout. For more details, visit this link https://wordpress.org/themes/spicepress/. We hope you will find the Content theme useful.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.3 ==
1. Update Theme Description.

= 1.2 ==
1. Update Description.

= 1.1 ==
1. Released

== Screenshot Images ==

* All images are licensed under [CC0]
https://www.pexels.com/photo/man-with-hand-on-temple-looking-at-laptop-842554/
https://www.pexels.com/photo/blanket-cliff-enjoyment-friendship-556958/
https://www.pexels.com/photo/woman-in-brown-long-sleeved-shirt-wearing-eyeglasses-holding-paint-brush-914922/