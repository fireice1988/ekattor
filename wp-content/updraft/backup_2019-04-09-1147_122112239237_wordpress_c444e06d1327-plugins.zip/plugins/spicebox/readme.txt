=== Spice Box ===
Contributors: spicethemes
Tags: widget, admin, widgets
Requires at least: 3.3+
Tested up to: 5.0.2
Stable tag: 0.3.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Enhance Spicethemes WordPress Themes functionality.

== Description ==

This plugin is the for SpicePress themes. It creates the slider section , service section, portfolio section and testimonial on home page in the Spicepress theme.
Spice Box is a plugin build to enhance the functionality of WordPress Theme made by Spicethemes.
This plugin create repeater controls in the customizer settings allowing you to create a live site without moving out to customizer screen. Right now plugin have a support for Spicepress WordPress Theme. In future this plugin will support other themes by Spicethemes.


== Changelog ==

= 0.1 =

* First version of the plugin.

= 0.2 =

* Changed plugin name spice box to spicebox.

= 0.2.1 =

* Fixed plugin review issue.

= 0.2.2 =

* String update

= 0.2.3 =

* Added Theme Name

= 0.2.4 =

* Added Theme Name

= 0.2.5 =

* Added Theme Name
* Added Overlay setting for slider and testimonial.

= 0.2.6 =

* Added Child Theme Name

= 0.2.7 =

* Added feedback popup form.

= 0.2.8 =

* Added some more field in feedback form.
* Style Feedback form.

= 0.2.9 =

* Created theme inner pages.

= 0.3 =

* Disable spicepress theme feedback popup form for security reasons.

= 0.3.1 =

1. Added Child theme functionality.

= 0.3.2 =

1. Remove Dobule backslah from images.

= 0.3.3 =

1. Added Innofit theme functionality.
2. Added Child theme name.

= 0.3.4 =

1. Fixed testimonial markup issue.

= 0.3.5 =

1. Added Innofit Plus functionality.